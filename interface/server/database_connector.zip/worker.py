import socket
import json
import sqlite3
import os
import cPickle as pickle
import subprocess
import queue_models as qm
import time

def send_result(server_ip,server_port,task_id,worker_ip):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((server_ip,server_port))
    client.send('finish %s %s'%(task_id,worker_ip))
    client.close()
    
def send_cmd(server_ip,server_port,worker_ip,worker_port):
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((server_ip,server_port))
        client.send('online %s:%s'%(worker_ip,worker_port))
    finally:
        client.close()
    
def register_node(server_ip,server_port,worker_ip,worker_port):
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((server_ip,server_port))
        client.send('online %s:%s'%(worker_ip,worker_port))
        return 1
    except Exception:
        print "Can't connect to QueueManager"
        return 0
    finally:
        client.close()
    
def configure_worker():
    print socket.gethostbyname_ex(socket.gethostname())[2][0]
def get_def(project_dir):
    files = os.listdir(project_dir)
    defs = filter(lambda x: x.endswith('.def'), files)
    return defs[0]
    
def start_CFX(task):
    CFXROOT = os.environ['AWP_Root150']+'\\CFX\\bin\\'
    options = json.loads(task.options)
    cmd = []
    cmd.append(CFXROOT+'cfx5solve')
    cmd.append(['-chdir ',task.path])
    # cmd.append(task.path)
    deffile = get_def(task.path)
    cmd.append(["-def ",deffile])
    if not task.moretime:
        cmd.append(["-maxet ","\"3 [hr]\""])
    for key,value in options:
        cmd.append(key+" ")
        cmd.append(value+" ")
    result = subprocess.call(cmd)
    print result
    return result

if __name__=='__main__':    
    worker = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    worker_ip = unicode(socket.gethostbyname_ex(socket.gethostname())[2][0])
    worker_port = 2728
    worker.bind((worker_ip, worker_port))
    worker.listen(2)
    manager_ip = '10.50.70.173'
    manager_port = 2727
    registred = register_node(manager_ip,manager_port,worker_ip,worker_port)
    while True:
        channel, details = worker.accept()
        data = channel.recv(1024)
        # channel.send('response')
        if data == 'ping':
            send_cmd(manager_ip,manager_port,worker_ip,worker_port)
            continue
        data_unpack = pickle.loads(data)
        print data_unpack.options
        options = json.loads(data_unpack.options)
        if data_unpack:
            # start_CFX(data_unpack)
            print data_unpack
            send_result(manager_ip,manager_port,data_unpack.id,worker_ip)
    worker.close()
    # 89060738230